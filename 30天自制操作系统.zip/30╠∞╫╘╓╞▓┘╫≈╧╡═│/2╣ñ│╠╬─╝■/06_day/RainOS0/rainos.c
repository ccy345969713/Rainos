#include <stdio.h>
#include "rainos.h"

void HariMain(void)
{
	struct BOOTINFO *binfo;	
	extern char hankaku[4096];
	char s[40],mcursor[256];
	int mx, my;
	
	//初始化GDT和IDT
	init_gdtidt();
	
	//初始化调色板
	init_palette();
	
	//初始化屏幕
	binfo = (struct BOOTINFO *)0x0ff0;
	init_screen(binfo->vram, binfo->scrnx, binfo->scrny);
	
	//初始化鼠标指针
	mx = (binfo->scrnx - 16)/2;
	my = (binfo->scrny - 28 - 16)/2;
	init_mouse_cursor8(mcursor, COL8_008484);
	putblock8_8(binfo->vram, binfo->scrnx, 16, 16, mx, my, mcursor, 16);
	
	//显示文字
	sprintf(s, "scrnx = %d", binfo->scrnx);
	putfonts8_asc(binfo->vram, binfo->scrnx, 16, 64, COL8_FFFFFF, s);

	//切换至待机状态
	for (;;) {
		io_hlt();
	}
}